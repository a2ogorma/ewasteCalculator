import spectrochempy as scp
# run in C:\Users\AidanO'Gorman\Universal Matter Inc Dropbox\Aidan O'Gorman\UMI Lab Desktop\Spectra\HIC\Map\H43-TCB1000 ESCORE
x = scp.read_omnic('TCB1000 ESCORE0001.spa') #reads spectra
xgroup = scp.read_omnic('TCB1000 ESCORE-group.spg') # reads groups too!
xgroup.plot()