# -*- coding: utf-8 -*-
"""
Created on Mon Aug  2 08:31:30 2021

@author: Tyler Cooksey
"""
import numpy as np
from numpy.linalg import norm
import scipy as sp
from scipy.signal import savgol_filter
import pandas as pd
import re
import os
from os import listdir
from os.path import isfile, join
from collections import defaultdict

def dictionary():
    return defaultdict(dictionary)


"""
This section is for analyzing the Raman data
"""

# regions devoid of signal
bir = np.array([[1000, 1200], [1700, 2100], [2900, 3500]])
lb = 1000  # The lower boundary of interest
hb = 3500  # The upper boundary of 9interest

raman_df_columns = ['File Name', 'D Position (cm^-1)', 'D Intensity (norm.)', 'D Width (cm^-1)',
                    'G Position (cm^-1)', 'G Intensity (norm.)', 'G Width (cm^-1)',
                    '2D Position (cm^-1)', '2D Intensity (norm.)', '2D Width (cm^-1)',
                    'D/G Ratio', '2D/G Ratio']

raman_df = pd.DataFrame(columns=raman_df_columns)



def find_nearest(array, value):  # finds value in array nearest target
    array = np.asarray(array)
    # this is the index of that closest value
    idx = (np.abs(array - value)).argmin()
    return array[idx], idx  # returns true value and the index


def peak_fitting(spect):
    peaks, _ = sp.signal.find_peaks(spect, distance=100, height=0.1)
    widths = sp.signal.peak_widths(spect, peaks)
    return peaks, widths


def baseline_als(y, lam, ratio):
    i = 0
    L = len(y)
    D = sp.sparse.diags([1, -2, 1], [0, -1, -2], shape=(L, L-2))
    D = lam * D.dot(D.transpose())
    w = np.ones(L)
    # for i in range(niter):
    W = sp.sparse.spdiags(w, 0, L, L)
    while True:
        W.setdiag(w)
        Z = W + D
        z = sp.sparse.linalg.spsolve(Z, w*y)
        d = y-z
        dn = d[d < 0]
        m = np.mean(dn)
        s = np.std(dn)
        wt = 1.0/(1 + sp.special.expit(2 * (d-(2*s-m))/s))
        # check exit condition and backup
        if (norm(w-wt)/norm(w)) < ratio:
            break
        w = wt
    return z

filenametest = re.compile(r'\.[A-z]{3}$')
filenametype = re.compile(r'\.csv$',re.IGNORECASE)

def RAMANScript():
    dbdict = dictionary()
    files = [f for f in listdir(os.curdir) if isfile(join(os.curdir,f))]

    for filename in files:
        if not filenametest.search(filename):
            continue
        
        if filenametype.search(filename):
            spectrum = np.genfromtxt(filename, skip_header=0, delimiter= ",")
        else:
            spectrum = np.genfromtxt(filename, skip_header=1)
            
        x = spectrum[:, 0]
        y = spectrum[:, 1]
        # for trimming the spectrum to boundary of interest
        spectrum_x = x[np.where((x > lb) & (x < hb))]
        spectrum_x = spectrum_x[np.newaxis].T
        spectrum_y = y[np.where((x > lb) & (x < hb))]
        spectrum_y = spectrum_y[np.newaxis].T
        spectrum = np.concatenate((spectrum_x, spectrum_y), axis=1)
        spectrum_smooth = savgol_filter(spectrum[:, 1], 11, 3)
        
        deadzone_y = y[np.where((x > 1700) & (x < 2100))]

        # y_fit = y_corr[np.where((x > lb)&(x < hb))] #for trimming the spectrum

        #ycalc_arpls, base_arpsl = rp.baseline(spectrum[:,0],spectrum_smooth,bir,'drPLS',lam=10**5,ratio=0.01)
        base_arpls = baseline_als(spectrum_smooth, lam=10**10, ratio=0.01)
        baseline = np.array(base_arpls)
        
        spectrum_base = np.subtract(spectrum_smooth, baseline)
        spectrum_norm = spectrum_base/np.amax(spectrum_base)
        spectrum_peaks, spectrum_widths = peak_fitting(spectrum_norm.flatten())
        spectrum_widths = np.asarray(spectrum_widths)
        db_values = np.zeros([1, 12])
        for jj in range(len(spectrum_peaks)):
            if 1200 <= float(spectrum[spectrum_peaks[jj], 0]) < 1450:  # D peak check
                db_values[0, 1] = float(
                    spectrum[spectrum_peaks[jj], 0])  # D peak position
                db_values[0, 2] = float(
                    spectrum_norm[spectrum_peaks[jj]])  # D peak intensity
                db_values[0, 3] = spectrum_widths[0, jj]  # D peak width
            elif 1450 <= float(spectrum[spectrum_peaks[jj], 0]) < 1700:  # G peak check
                db_values[0, 4] = float(
                    spectrum[spectrum_peaks[jj], 0])  # G peak position
                db_values[0, 5] = float(
                    spectrum_norm[spectrum_peaks[jj]])  # G peak intensity
                db_values[0, 6] = spectrum_widths[0, jj]  # G peak width
            elif 2500 <= float(spectrum[spectrum_peaks[jj], 0]) < 2900:  # 2D peak check
                db_values[0, 7] = float(
                    spectrum[spectrum_peaks[jj], 0])  # 2D peak position
                db_values[0, 8] = float(
                    spectrum_norm[spectrum_peaks[jj]])  # 2D peak intensity
                db_values[0, 9] = spectrum_widths[0, jj]  # 2D peak width
        if db_values[0, 5] != 0:  # G peak value check
            db_values[0, 10] = db_values[0, 2]/db_values[0, 5]  # D/G calculation
            db_values[0, 11] = db_values[0, 8]/db_values[0, 5]  # 2D/G calculation

        #checks to ensure only relevant data is included
        if sp.stats.tstd(deadzone_y) > 0.05*max(spectrum_base): #signal to noise check between 1700-2100cm-1, where it should largely be flat. Compared against the max intensity of the spectrum (usually G). If the noise is larger than 5% of the max spectrum intensity, it is rejected.
            print('Signal to Noise Ratio too low on '+filename)
            continue
        if any([db_values[0, 1] == 0,db_values[0, 4] == 0, db_values[0, 7] == 0, (db_values[0, 5] < 1 and db_values[0, 2] < 1 and db_values[0, 8] < 1)]): #removal of samples with nonsense data (any peaks larger than the expected ones would be a result of errors)
            print("Data from "+filename+" was not included in the calculations.")
            continue
        dbdict[filename] = db_values.flatten()
    
    export_df = pd.DataFrame.from_dict(dbdict,orient='index', columns=raman_df_columns) 
    dbdict["Mean"] = export_df.mean()
    dbdict["Standard Deviation"] = export_df.std()
    export_df = pd.DataFrame.from_dict(dbdict,orient='index', columns=raman_df_columns)
    export_df.drop(columns = 'File Name', axis = 1, inplace= True)
    resultfilename = "ResultsRaw.xlsx"
    with pd.ExcelWriter(resultfilename) as writer:
        export_df.to_excel(writer)


RAMANScript()
