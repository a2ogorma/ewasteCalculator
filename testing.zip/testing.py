import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import seaborn as sns
from collections import defaultdict


def dictionary():
    return defaultdict(dictionary)

material = "High D MC"

datafile = pd.read_excel('ResultsRaw.xlsx')
num_points = len(datafile)
material = material + " " + str(num_points)
Davg = datafile[-2:].iat[0,10]
D2avg = datafile[-2:].iat[0,11]
Dstddev = datafile[-1:].iat[0,10]
D2stddev = datafile[-1:].iat[0,11]
datafile.drop(datafile.tail(2).index,inplace=True)
#D2Gratio = datafile
fig, axs = plt.subplots(2, 1, tight_layout = True)
fig.suptitle(material)
#ax2 = axs.twinx()
#ax2 = axs.secondary_yaxis('right')\
UMIcmap = plt.cm.get_cmap("Reds").copy()
UMIcmap.set_under('white',2)
axs[0].hist(datafile["D/G Ratio"][0:num_points], range=[0,1.1], bins=40, color="red")
axs[0].set_ylabel("Frequency")
axs[0].set_xlabel(''.join(["D/G Ratio (Average = ",str(round(Davg,3))," ",u"\u00B1"," ",str(round(Dstddev,3)),")"]))
axs2 = axs[0].twinx()
axs2.hist(datafile["D/G Ratio"][0:num_points], range=[0,1.1], histtype='step', cumulative=True, density=True, bins=40, color="black")
axs2.set_ylabel("Cumulative Frequency")

axs[1].hist(datafile["2D/G Ratio"][0:num_points], range=[0,1.1], bins=40, color="red")
axs[1].set_ylabel("Frequency")
axs[1].set_xlabel(''.join(["2D/G Ratio (Average = ",str(round(D2avg,3))," ",u"\u00B1"," ",str(round(D2stddev,3)),")"]))
axs3 = axs[1].twinx()
axs3.hist(datafile["2D/G Ratio"][0:num_points], range=[00,1.1], cumulative=True, histtype='step', density=True, bins=40, color="black")
axs3.set_ylabel("Cumulative Frequency")

fig, ax = plt.subplots()
fig.suptitle(material)
plt.hist2d(datafile["D/G Ratio"][0:num_points],datafile["2D/G Ratio"][0:num_points], range=[[0,1.1],[0,1.1]], bins=50, cmap=UMIcmap)
ax.set_ylabel(''.join(["2D/G Ratio (Average = ",str(round(D2avg,3))," ",u"\u00B1"," ",str(round(D2stddev,3)),")"]))
ax.set_xlabel(''.join(["D/G Ratio (Average = ",str(round(Davg,3))," ",u"\u00B1"," ",str(round(Dstddev,3)),")"]))
plt.show()
    
    
from PyMca5.PyMcaIO import OmnicMap
omnic_file = OmnicMap.OmnicMap(filename)
omnic_file.data #shows spectra in array based on size
