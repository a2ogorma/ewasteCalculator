import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import matplotlib.patches as patches
from collections import defaultdict


def dictionary():
    return defaultdict(dictionary)


datafile = pd.read_excel('ResultsRaw.xlsx');
material = 'High D MC'
#D2Gratio = datafile
#print(D2Gratio)
#D2Gratio.head()
columnInfo = datafile.columns.tolist()
columnInfo.pop(0)
columnInfo[9] = "DG Ratio"
columnInfo[10] = "2DG Ratio"
resultfilename = "Results.xlsx"
datasize = len(datafile)-1
sequence = np.arange(1, datasize+1)
runs = 100 # number of simulated average runs to do
columnInfoMean = ["Mean " + name for name in columnInfo]
columnInfoStd = ["StdDev " + name for name in columnInfo]
SamplingNumbers = [1, 6, 10, 36, 60, 100, 200, len(datafile)-1]
runresults = []
DGstandardDevPlotting = []
D2GstandardDevPlotting = []
for run in range(runs):
    np.random.shuffle(sequence) #shuffles the contents of rand1
    dbdict = dictionary()
    avgdict = dictionary()
    stddict = dictionary()
    averageForRun = []
    seqNo = 0
    for iter in sequence:
        averageBySequence = []
        seqNo = seqNo+1
        print(seqNo)
        selected_row = np.arange(0,11, dtype=np.double)
        for pt in selected_row:
            selected_row[int(pt)] = datafile.at[iter, datafile.columns[pt+1]]
        #add selected row to data array
        dbdict[iter] = selected_row.flatten()
        DF = pd.DataFrame.from_dict(dbdict,orient='index', columns=columnInfo)  
        avgdict[seqNo] = DF.mean()
        stddict[seqNo] = DF.std()

    #tabularData = np.empty((len(SamplingNumbers)+1,22))
    #print(tabularData)
    DGstandardDevPlotting.append(pd.DataFrame.from_dict(stddict,orient='index')["DG Ratio"])
    D2GstandardDevPlotting.append(pd.DataFrame.from_dict(stddict,orient='index')["2DG Ratio"])
    tabularData = [columnInfoMean, columnInfoStd]
    #print(tabularData)
    for nums in SamplingNumbers:
        tabularData.append([avgdict[nums].tolist(), stddict[nums].tolist()])
    runresults.append(tabularData)
    
    #for pt in selected_row:
    #    DF[columnInfoMean[pt]] = avgdict[columnInfo[pt]]
    #    DF[columnInfoStd[pt]] = stddict[columnInfo[pt]]
    #data_df = pd.DataFrame.from_dict(dbdict,orient='index', columns=columnInfo)
    #exMean_df = pd.DataFrame.from_dict(avgdict,orient='index', columns=columnInfoMean)
    #exStd_df = pd.DataFrame.from_dict(stddict,orient='index', columns=columnInfoStd)
    #all_df = data_df+exMean_df+exStd_df
    #all_df = pd.concat([data_df, exMean_df, exStd_df], axis=1)
    #data_df = data_df.append(exMean_df)
    #data_df = data_df.append(exStd_df)
    #resultfilename = "Results.xlsx"
    # need to figure out how to add the mean and std data to the results
    #with pd.ExcelWriter(resultfilename) as writer:
    #    data_df.to_excel(writer, sheet_name = 'data')
        #exMean_df.to_excel(writer, sheet_name = 'mean')
        #exStd_df.to_excel(writer, sheet_name = 'std')
DGstandardDevPlotting = np.transpose(DGstandardDevPlotting)
D2GstandardDevPlotting = np.transpose(D2GstandardDevPlotting)

stdDev = DGstandardDevPlotting[datasize-1,-1]
fig, axs = plt.subplots(1, 1, tight_layout = True)
fig.suptitle(' '.join([material,": D/G Standard Deviation over ",str(runs)," runs"]))
plt.plot(range(0,datasize),DGstandardDevPlotting)
for nums in SamplingNumbers:
    rect = patches.Rectangle((nums,min(DGstandardDevPlotting[nums-1,:])), 5 if nums < 10 else 10, np.ptp(DGstandardDevPlotting[nums-1,:]), linewidth=1, edgecolor='none', facecolor='red', alpha=0.5, zorder=2)
    axs.add_patch(rect)
    plt.text(nums+10,max(DGstandardDevPlotting[nums-1,:]),' '.join(["[",str(nums),"pts:",str(round(min(DGstandardDevPlotting[nums-1,:]),3)),",",str(round(max(DGstandardDevPlotting[nums-1,:]),3)),"]"]))
axs.set_xlabel("Number of sample points used")
axs.set_ylabel("Standard deviation at sample size")

fig, axs = plt.subplots(1, 1, tight_layout = True)
DGstdDevRange = []
DGpctDevRange = []
for pointval in range(1,datasize):
    DGstdDevRange.append(0.5*np.ptp(DGstandardDevPlotting[pointval,:]))
    DGpctDevRange.append(DGstdDevRange[-1]/stdDev)
fig.suptitle(' '.join([material,": D/G range of standard deviation"]))
plt.plot(DGstdDevRange)
axs.set_xlabel("Number of sample points used")
axs.set_ylabel("Half of absolute range")

axs2 = axs.twinx()
plt.plot(DGpctDevRange)
axs2.yaxis.set_major_formatter(mtick.PercentFormatter(1.0))
axs2.set_ylabel("% of total standard deviation")

stdDev = D2GstandardDevPlotting[datasize-1,-1]
fig, axs = plt.subplots(1, 1, tight_layout = True)
fig.suptitle(' '.join([material,": 2D/G Standard Deviation over ",str(runs)," runs"]))
plt.plot(range(0,datasize),D2GstandardDevPlotting)
for nums in SamplingNumbers:
    rect = patches.Rectangle((nums,min(D2GstandardDevPlotting[nums-1,:])), 5 if nums < 10 else 10, np.ptp(D2GstandardDevPlotting[nums-1,:]), linewidth=1, edgecolor='none', facecolor='red', alpha=0.5, zorder=2)
    axs.add_patch(rect)
    plt.text(nums+10,max(D2GstandardDevPlotting[nums-1,:]),' '.join(["[",str(nums),"pts:",str(round(min(D2GstandardDevPlotting[nums-1,:]),3)),",",str(round(max(D2GstandardDevPlotting[nums-1,:]),3)),"]"]))
axs.set_xlabel("Number of sample points used")
axs.set_ylabel("Standard deviation at sample size")

fig, axs = plt.subplots(1, 1, tight_layout = True)
D2GstdDevRange = []
D2GpctDevRange = []
for pointval in range(1,datasize):
    D2GstdDevRange.append(0.5*np.ptp(D2GstandardDevPlotting[pointval,:]))
    D2GpctDevRange.append(D2GstdDevRange[-1]/stdDev)
fig.suptitle(' '.join([material,": 2D/G range of standard deviation"]))
plt.plot(D2GstdDevRange)
axs.set_xlabel("Number of sample points used")
axs.set_ylabel("Half of absolute range")

axs2 = axs.twinx()
plt.plot(D2GpctDevRange)
axs2.yaxis.set_major_formatter(mtick.PercentFormatter(1.0))
axs2.set_ylabel("% of total standard deviation")

plt.show()

#this spits out all the run average values

rundict = dictionary()
RunData = []
for datavalue in range(11): #done by parameter
    ab_values = np.zeros([1, len(SamplingNumbers)])
    runsByParameter = []#ab_values[0]
    for run in range(runs): #then by run
        samplesByRun = []
        for samplePoints in range(len(SamplingNumbers)): #then sampling numbers
            samplesByRun.append(runresults[run][samplePoints+2][0][datavalue])
        runsByParameter.append(samplesByRun)
        rundict[run] = runsByParameter[run]
    RunData_df = pd.DataFrame.from_dict(rundict,orient='index', columns=SamplingNumbers)
    RunData.append(RunData_df)


#this puts all the aggregate info together into average, standard dev and pct std dev for all runs
output_struct = []
for samplePoints in range(len(SamplingNumbers)):
    
    datavals = []
    for datavalue in range(11):
        run_vals = []
        for run in range(runs):
            run_vals.append(runresults[run][samplePoints+2][0][datavalue])
        stdval = np.std(run_vals)
        avgval = np.mean(run_vals)
            
        datavals.append([avgval, stdval])
    output_struct.append(datavals)

outdict = dictionary()
columnAll = ['Sampling Numbers']
columnAll.extend(columnInfoMean)
columnAll.extend(columnInfoStd)
columnAll.extend(["Pct " + name for name in columnInfoStd])
for nums in range(len(SamplingNumbers)):
    ab_values = np.zeros([1, 34])
    db_values = ab_values[0]
    db_values[0] = SamplingNumbers[nums] #notes which sample value has the data
    for column_vals in range(len(columnInfo)):
        db_values[column_vals+1] = output_struct[nums][column_vals][0] #average values
        db_values[column_vals+12] = output_struct[nums][column_vals][1] #stDev values
        db_values[column_vals+23] = output_struct[nums][column_vals][1]/output_struct[nums][column_vals][0] #percent stDev values
    outdict[nums] = db_values.flatten()
AggData_df = pd.DataFrame.from_dict(outdict,orient='index', columns=columnAll)
resultfilename = "Results.xlsx"
    # need to figure out how to add the mean and std data to the results

with pd.ExcelWriter(resultfilename) as writer:
    AggData_df.to_excel(writer, sheet_name="aggregate")
    for datavalue in range(11):
        RunData[datavalue].to_excel(writer, sheet_name=columnInfo[datavalue])
    #NEED
#average for each value (at end of output struct)
#output distribution for 500 points
#D/G and 2D/G bivariate histogram

#animated plot showing the 10 point selection example
#this puts all the run average data together
